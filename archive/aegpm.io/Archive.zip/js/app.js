particlesJS.load('particles-js', 'particlesjs.json', function() {
  console.log('particles.js loaded - callback');
});
